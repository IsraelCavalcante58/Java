---
title: Arrow up right square
layout: icon
categories:
  - Shape Arrows
tags:
  - arrow
  - square
---
