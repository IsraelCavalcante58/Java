---
title: Aspect ratio fill
categories:
  - Media
tags:
  - size
  - resize
  - crop
  - dimensions
---
