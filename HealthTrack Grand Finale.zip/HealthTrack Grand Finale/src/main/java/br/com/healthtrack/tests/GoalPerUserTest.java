package br.com.healthtrack.tests;

import java.util.List;

import br.com.healthtrack.data.dao.GoalPerUserDAO;
import br.com.healthtrack.data.model.GoalPerUser;

public class GoalPerUserTest {
    public static void main(String[] args) {

        GoalPerUserDAO goalPerUserDAO = new GoalPerUserDAO();

//        GoalPerUser goalPerUser = new GoalPerUser(185,  )

        List<GoalPerUser> listaGoalPerUser = goalPerUserDAO.selectAll();

        for (GoalPerUser item : listaGoalPerUser) {
            System.out.println("ID da tabela associativa Goal User: " + item.getIdGoalPerUser() + "\nID do usuário vinculado a meta: " + item.getUserId() + "\nID da meta vinculada: " + item.getIdGoal());
            System.out.println("");
            System.out.println("");
        }
    }
}
