package br.com.healthtrack.business.model.user;
// Classe ainda não implementada
public class Skill {
}
