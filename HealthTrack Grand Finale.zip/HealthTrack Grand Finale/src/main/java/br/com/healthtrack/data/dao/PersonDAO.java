package br.com.healthtrack.data.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.healthtrack.business.model.user.Gender;
import br.com.healthtrack.business.model.user.Person;

public class PersonDAO implements DaoCRUD<Person> {

    @Override
    public int create(Person person) {
        PreparedStatement statement;
        try {
            statement = connection.prepareStatement(
                    "INSERT INTO T_HT_PERSON(ID_PERSON, NM_NAME, EM_EMAIL, PS_PASS, DT_BIRTHDATE, GEN_GENDER) " +
                            "VALUES (SQ_PERSON.NEXTVAL, ?, ?, ?, ?,?)");

            statement.setString(1, person.getName());
            statement.setString(2, person.getEmail());
            statement.setString(3, person.getPassword());
            Date data = new Date(person.getBirthDate().getTime());
            statement.setDate(4, data);
            statement.setInt(5, person.getGender().getCode());
            return databaseManager.executeWriteQuery(statement);
        } catch (SQLException e) {
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (PERSONDAO)");
        }
        return 0;
    }


    @Override
    public int update(Person person) {
        return 0;
    }

    @Override
    public int update(List<Person> t) {
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int delete(Person person) {
        return 0;
    }

    @Override
    public Person findById(int id) {
        return null;
    }

    @Override
    public List<Person> selectAll() {

        ResultSet resultSet;
        List<Person> listPerson = new ArrayList<>();
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM T_HT_PERSON");
            resultSet = databaseManager.executeReadQuery(statement);


//    public Person(long idPerson, String namePerson, String passPerson, String birthDate, String email, Gender gender) {


            while (resultSet.next()) {


                Gender gender = Gender.getEnumByValue(resultSet.getInt("GEN_GENDER"));
                listPerson.add(new Person(

                        resultSet.getLong("ID_PERSON"),
                        resultSet.getString("NM_NAME"),
                        resultSet.getString("PS_PASS"),
                        resultSet.getString("DT_BIRTHDATE"),
                        resultSet.getString("EM_EMAIL"),
                        gender));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listPerson;
    }
}
