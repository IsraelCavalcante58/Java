package br.com.healthtrack.data.dao.diet;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import br.com.healthtrack.business.model.diet.MeasurementUnit;
import br.com.healthtrack.data.dao.DaoCRUD;

public class MeasurementUnitDAO implements DaoCRUD<MeasurementUnit> {

    @Override
    public int create(MeasurementUnit unit) {
        PreparedStatement statement;
        try {
            connection.beginRequest();
            statement = connection.prepareStatement(
                    "INSERT INTO T_HT_UNIT(ID_UNIT, DS_DESCRIPTION, DS_SHORT_DESC)" +
                            " VALUES (?, ?, ?)");

            statement.setInt(1, unit.getId());
            statement.setString(2, unit.getDescription());
            statement.setString(3, unit.getShortForm());
            return databaseManager.executeWriteQuery(statement);
        } catch (SQLException e) {
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (IngredientDAO - CREATE)");
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int update(MeasurementUnit measurementUnit) {
        return 0;
    }

    @Override
    public int update(List<MeasurementUnit> t) {
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int delete(MeasurementUnit measurementUnit) {
        return 0;
    }

    @Override
    public MeasurementUnit findById(int id) {
        return null;
    }

    @Override
    public List<MeasurementUnit> selectAll() {
        return null;
    }
}
