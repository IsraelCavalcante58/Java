package br.com.healthtrack.tests;

import java.util.List;

import br.com.healthtrack.business.model.user.Goal;
import br.com.healthtrack.data.dao.GoalDao;

public class GoalTest {
    public static void main(String[] args) {

        Goal goal1 = ObjectFactory.createGoal1();
        Goal goal2 = ObjectFactory.createGoal2();
        Goal goal3 = ObjectFactory.createGoal3();
        Goal goal4 = ObjectFactory.createGoal4();
        Goal goal5 = ObjectFactory.createGoal5();

        GoalDao goalDao = new GoalDao();
        goalDao.create(goal1);
        goalDao.create(goal2);
        goalDao.create(goal3);
        goalDao.create(goal4);
        goalDao.create(goal5);

        List<Goal> listaGoal = goalDao.selectAll();
        for (Goal item : listaGoal) {
            System.out.println("ID da meta: " + item.getId() + " Tipo de meta: " + item.getGoalType());
        }
    }
}