package br.com.healthtrack.data.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.healthtrack.business.model.user.Goal;

public class GoalDao implements DaoCRUD<Goal> {
    @Override
    public int create(Goal goal) {
        PreparedStatement statement;
        try {
            statement = connection.prepareStatement(
                    "INSERT INTO T_HT_GOAL(ID_GOAL, DS_GOAL_TYPE)" +
                            " VALUES (SQ_GOAL.NEXTVAL, ?)");

            statement.setString(1, goal.getGoalType());
            return databaseManager.executeWriteQuery(statement);

        } catch (SQLException e) {
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (GoalDao)");
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int update(Goal goal) {
        return 0;
    }

    @Override
    public int update(List<Goal> t) {
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int delete(Goal goal) {
        return 0;
    }

    @Override
    public Goal findById(int id) {
        return null;
    }

    @Override
    public List<Goal> selectAll() {

        ResultSet resultSet;
        List<Goal> goals = new ArrayList<>();
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM T_HT_GOAL");
            resultSet = databaseManager.executeReadQuery(statement);

            while (resultSet.next()) {
                goals.add(new Goal(
                        resultSet.getLong("ID_GOAL"),
                        resultSet.getString("DS_GOAL_TYPE")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return goals;
    }

}

