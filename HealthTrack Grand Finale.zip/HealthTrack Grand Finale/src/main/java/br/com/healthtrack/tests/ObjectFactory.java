package br.com.healthtrack.tests;

import java.util.ArrayList;
import java.util.List;

import br.com.healthtrack.business.model.diet.Diet;
import br.com.healthtrack.business.model.diet.Ingredient;
import br.com.healthtrack.business.model.diet.Meal;
import br.com.healthtrack.business.model.diet.MealOption;
import br.com.healthtrack.business.model.diet.MeasurementUnit;
import br.com.healthtrack.business.model.user.Appointment;
import br.com.healthtrack.business.model.user.Customer;
import br.com.healthtrack.business.model.user.Gender;
import br.com.healthtrack.business.model.user.Goal;
import br.com.healthtrack.business.model.user.Instructor;
import br.com.healthtrack.business.model.user.Nutritionist;
import br.com.healthtrack.business.model.user.WeightRecord;

public class ObjectFactory {

    public static Diet createDiet1(long idUser) {

        Ingredient ingredient1 = new Ingredient("banana", 2, MeasurementUnit.UNIT);
        Ingredient ingredient2 = new Ingredient("canela", 2, MeasurementUnit.GRAMS);
        Ingredient ingredient3 = new Ingredient("aveia", 100, MeasurementUnit.GRAMS);

        List<Ingredient> ingredients = new ArrayList<>();

        ingredients.add(ingredient1);
        ingredients.add(ingredient2);
        ingredients.add(ingredient3);

        MealOption mealOption = new MealOption(ingredients, "Amasse as bananas, a canela e a aveia.");

        List<MealOption> mealOptions = new ArrayList<>();
        mealOptions.add(mealOption);

        Meal meal = new Meal("café da manha", mealOptions);

        List<Meal> meals = new ArrayList<>();
        meals.add(meal);

        Diet dieta = new Diet(idUser, meals, "Tomar dois copos de água ao acordar e antes de dormir");
        return dieta;
    }

    public static Diet createDiet2(long idUser) {

        Ingredient ingredient1 = new Ingredient("abacaxi", 2, MeasurementUnit.UNIT);
        Ingredient ingredient2 = new Ingredient("arroz", 2, MeasurementUnit.GRAMS);
        Ingredient ingredient3 = new Ingredient("aveia", 100, MeasurementUnit.GRAMS);

        List<Ingredient> ingredients = new ArrayList<>();

        ingredients.add(ingredient1);
        ingredients.add(ingredient2);
        ingredients.add(ingredient3);

        MealOption mealOption = new MealOption(ingredients, "Amasse as bananas, a canela e a aveia.");

        List<MealOption> mealOptions = new ArrayList<>();
        mealOptions.add(mealOption);

        Meal meal = new Meal("café da manha", mealOptions);

        List<Meal> meals = new ArrayList<>();
        meals.add(meal);

        Diet dieta = new Diet(idUser, meals, "Tomar dois copos de água ao acordar e antes de dormir");
        return dieta;
    }

    public static Diet createDiet3(long idUser) {

        Ingredient ingredient1 = new Ingredient("Uva", 2, MeasurementUnit.UNIT);
        Ingredient ingredient2 = new Ingredient("Pêssego", 2, MeasurementUnit.GRAMS);
        Ingredient ingredient3 = new Ingredient("aveia", 100, MeasurementUnit.GRAMS);

        List<Ingredient> ingredients = new ArrayList<>();

        ingredients.add(ingredient1);
        ingredients.add(ingredient2);
        ingredients.add(ingredient3);

        MealOption mealOption = new MealOption(ingredients, "Amasse as bananas, a canela e a aveia.");

        List<MealOption> mealOptions = new ArrayList<>();
        mealOptions.add(mealOption);

        Meal meal = new Meal("café da manha", mealOptions);

        List<Meal> meals = new ArrayList<>();
        meals.add(meal);

        Diet dieta = new Diet(idUser, meals, "Tomar dois copos de água ao acordar e antes de dormir");
        return dieta;
    }

    public static Diet createDiet4(long idUser) {

        Ingredient ingredient1 = new Ingredient("Molho de tomate", 2, MeasurementUnit.UNIT);
        Ingredient ingredient2 = new Ingredient("Massa", 2, MeasurementUnit.GRAMS);
        Ingredient ingredient3 = new Ingredient("aveia", 100, MeasurementUnit.GRAMS);

        List<Ingredient> ingredients = new ArrayList<>();

        ingredients.add(ingredient1);
        ingredients.add(ingredient2);
        ingredients.add(ingredient3);

        MealOption mealOption = new MealOption(ingredients, "Amasse as bananas, a canela e a aveia.");

        List<MealOption> mealOptions = new ArrayList<>();
        mealOptions.add(mealOption);

        Meal meal = new Meal("café da manha", mealOptions);

        List<Meal> meals = new ArrayList<>();
        meals.add(meal);

        Diet dieta = new Diet(idUser, meals, "Tomar dois copos de água ao acordar e antes de dormir");
        return dieta;
    }

    public static Diet createDiet5(long idUser) {

        Ingredient ingredient1 = new Ingredient("Alecrim", 2, MeasurementUnit.UNIT);
        Ingredient ingredient2 = new Ingredient("Creme de leite", 2, MeasurementUnit.GRAMS);
        Ingredient ingredient3 = new Ingredient("Patinho", 100, MeasurementUnit.GRAMS);

        List<Ingredient> ingredients = new ArrayList<>();

        ingredients.add(ingredient1);
        ingredients.add(ingredient2);
        ingredients.add(ingredient3);

        MealOption mealOption = new MealOption(ingredients, "Amasse as bananas, a canela e a aveia.");

        List<MealOption> mealOptions = new ArrayList<>();
        mealOptions.add(mealOption);

        Meal meal = new Meal("café da manha", mealOptions);

        List<Meal> meals = new ArrayList<>();
        meals.add(meal);

        Diet dieta = new Diet(idUser, meals, "Tomar dois copos de água ao acordar e antes de dormir");
        return dieta;
    }

    public static Instructor createInstructor1() {
        Instructor instrutorTeste = new Instructor(334, "Luizaaainho", "3232456",
                "08/05/1983", "luizinho@gmail.com", Gender.MALE, "392832-235");
        return instrutorTeste;
    }

    public static Instructor createInstructor2() {
        Instructor instrutorTeste = new Instructor(233, "Gustinho", "390022",
                "08/05/1943", "gustinho@gmail.com", Gender.MALE, "32321-215");
        return instrutorTeste;

    }

    public static Instructor createInstructor3() {
        Instructor instrutorTeste = new Instructor(53, "Jessiquinha", "323452",
                "08/05/1923", "Jessiquinha@gmail.com", Gender.FEMALE, "92832-235");
        return instrutorTeste;
    }

    public static Instructor createInstructor4() {
        Instructor instrutorTeste = new Instructor(323, "Rafinha do grau", "323452",
                "08/05/2015", "rafinhazinhadograu@gmail.com", Gender.FEMALE, "323231-121");
        return instrutorTeste;

    }

    public static Instructor createInstructor5() {
        Instructor instrutorTeste = new Instructor(938, "leozinhodz7", "323452",
                "08/05/2015", "leozinhodz7@gmail.com", Gender.FEMALE, "23212-124");
        return instrutorTeste;
    }

    public static Customer createCustomer1() {
        Customer customerTest = new  Customer(30L, "ASDLLSAKDJALSJDSA", "323242-Senha",
                new WeightRecord(85.7), 198, "08/03/2005", "luizinhodamotoca@gmail.com", Gender.MALE);

        return customerTest;
    }

    public static Customer createCustomer2() {
        Customer customerTest = new Customer(232L, "Jessiquinha", "324234-Senha",
                new WeightRecord(33.7), 180, "08/03/1998", "JessiquinhaDaMotoca@gmail.com", Gender.FEMALE);
        return customerTest;
    }

    public static Customer createCustomer3() {
        Customer customerTest = new Customer(343L, "Guguinha", "324234-3242",
                new WeightRecord(55.3), 198, "08/03/1955", "GubinhaAmtttt@gmail.com", Gender.OTHER);
        return customerTest;
    }

    public static Customer createCustomer4() {
        Customer customerTest = new Customer(250L, "LeozinhoCareca", "523232",
                new WeightRecord(43.5), 170, "08/03/1923", "thomashelby@gmail.com", Gender.MALE);
        return customerTest;
    }

    public static Customer createCustomer5() {
        Customer customerTest = new Customer(3232L, "Wanda", "oi3892",
                new WeightRecord(43.5), 170, "08/03/1923", "wandavision@gmail.com", Gender.FEMALE);
        return customerTest;
    }

    public static Nutritionist createNutritionist1() {
        Nutritionist nutritionistTest = new Nutritionist(342, "Jessiquinha", "4332",
                "08/05/1900", "jessiquinhaterrorista@gmail.com", Gender.OTHER, "93234-23");
        return nutritionistTest;
    }

    public static Nutritionist createNutritionist2() {
        Nutritionist nutritionistTest = new Nutritionist(233, "Guguinha", "32543",
                "08/05/2002", "Guginhazinhu@gmail.com", Gender.OTHER, "684472-235");
        return nutritionistTest;
    }

    public static Nutritionist createNutritionist3() {
        Nutritionist nutritionistTest = new Nutritionist(987, "Luizinhuuh Silva", "73627",
                "08/05/2002", "dasdas@gmail.com", Gender.OTHER, "4532-235");
        return nutritionistTest;
    }

    public static Nutritionist createNutritionist4() {
        Nutritionist nutritionistTest = new Nutritionist(4674, "Leozinho", "5443",
                "08/05/2002", "leozinhodocrime@gmail.com", Gender.OTHER, "323-235");
        return nutritionistTest;
    }

    public static Nutritionist createNutritionist5() {
        Nutritionist nutritionistTest = new Nutritionist(4332, "Karine", "93829",
                "08/05/2001", "rafinhakariem.dev@gmail.com", Gender.OTHER, "32323-23325");
        return nutritionistTest;
    }

    public static Goal createGoal1() {
        Goal goalTest = new Goal(3, "Natação");
        goalTest.goalAdd(goalTest, 73);
        return goalTest;
    }

    public static Goal createGoal2() {
        Goal goalTest = new Goal(4, "Musculacão");
        goalTest.goalAdd(goalTest, 63);
        return goalTest;
    }

    public static Goal createGoal3() {
        Goal goalTest = new Goal(5, "Aeróbico");
        goalTest.goalAdd(goalTest, 53);
        return goalTest;
    }

    public static Goal createGoal4() {
        Goal goalTest = new Goal(6, "Iatismo");
        goalTest.goalAdd(goalTest, 43);
        return goalTest;
    }

    public static Goal createGoal5() {
        Goal goalTest = new Goal(7, "Alpinismo");
        goalTest.goalAdd(goalTest, 33);
        return goalTest;
    }

    public static Appointment createAppointment1() {
        Appointment appointmentTest = new Appointment(1, "08/05/2022", true, 193, 9323423);
        return appointmentTest;
    }


}
