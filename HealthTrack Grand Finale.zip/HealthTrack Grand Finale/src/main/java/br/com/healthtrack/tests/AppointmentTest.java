package br.com.healthtrack.tests;

import java.util.List;

import br.com.healthtrack.business.model.diet.Diet;
import br.com.healthtrack.business.model.user.Appointment;
import br.com.healthtrack.data.dao.AppointmentDAO;
import br.com.healthtrack.data.dao.diet.DietDao;

public class AppointmentTest {

    public static void main(String[] args) {

        Appointment appointment1 = ObjectFactory.createAppointment1();

        AppointmentDAO appointmentDAO = new AppointmentDAO();
        appointmentDAO.create(appointment1);

        List<Appointment> listaAppointment = appointmentDAO.selectAll();

        for (Appointment item : listaAppointment) {
            System.out.println("Registro de consulta " + item.getIdAppointment());
        }
    }


    private static Diet createDiet() {
        DietDao dietDao = new DietDao();

        return dietDao.findById(10);
    }
}
