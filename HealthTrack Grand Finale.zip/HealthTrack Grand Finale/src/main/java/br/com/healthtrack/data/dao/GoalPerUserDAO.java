package br.com.healthtrack.data.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.healthtrack.business.model.user.Goal;
import br.com.healthtrack.data.model.GoalPerUser;

public class GoalPerUserDAO implements DaoCRUD<GoalPerUser> {

    @Override
    public int create(GoalPerUser goalPerUser) {

        PreparedStatement statement;
        int affectedRows = 0;
        try {
            for (Goal goal : goalPerUser.getGoals()) {

                statement = connection.prepareStatement(
                        "INSERT INTO T_HT_GOAL_USER(ID_GOAL_USER, T_HT_CUSTOMER_ID_PERSON, T_HT_GOAL_ID_GOAL)" +
                                " VALUES (SQ_GOAL_USER.NEXTVAL, ?, ?)");
                statement.setLong(1, goalPerUser.getUserId());
                statement.setLong(2, goal.getId());
                databaseManager.executeWriteQuery(statement);
                affectedRows++;
            }
            return affectedRows;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int update(GoalPerUser goalPerUser) {
        return 0;
    }

    @Override
    public int update(List<GoalPerUser> t) {
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int delete(GoalPerUser goalPerUser) {
        return 0;
    }

    @Override
    public GoalPerUser findById(int id) {
        return null;
    }

    @Override
    public List<GoalPerUser> selectAll() {

        ResultSet resultSet;
        List<GoalPerUser> listGoalPerUser = new ArrayList<>();
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM T_HT_GOAL_USER");
            resultSet = databaseManager.executeReadQuery(statement);

            while (resultSet.next()) {
                listGoalPerUser.add(new GoalPerUser(
                        resultSet.getLong("ID_GOAL_USER"),
                        resultSet.getLong("T_HT_CUSTOMER_ID_PERSON"),
                        resultSet.getLong("T_HT_GOAL_ID_GOAL")));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return listGoalPerUser;
    }
}
