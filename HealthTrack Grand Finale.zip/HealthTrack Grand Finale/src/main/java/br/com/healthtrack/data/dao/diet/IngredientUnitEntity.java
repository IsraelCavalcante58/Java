package br.com.healthtrack.data.dao.diet;

public class IngredientUnitEntity {
    private long idIngredient;
    private long idUnit;
    private int quantity;
    private long mealOptionId;

    public IngredientUnitEntity(long idIngredient, long idUnit, int quantity) {
        this.idIngredient = idIngredient;
        this.idUnit = idUnit;
        this.quantity = quantity;
    }

    public long getIdIngredient() {
        return idIngredient;
    }

    public long getIdUnit() {
        return idUnit;
    }

    public int getQuantity() {
        return quantity;
    }

    public long getMealOptionId() {
        return mealOptionId;
    }

    public void setMealOptionId(long mealOptionId) {
        this.mealOptionId = mealOptionId;
    }
}
