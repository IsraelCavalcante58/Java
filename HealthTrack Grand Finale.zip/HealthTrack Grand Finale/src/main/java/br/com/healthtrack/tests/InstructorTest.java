package br.com.healthtrack.tests;

import java.util.List;

import br.com.healthtrack.business.model.user.Instructor;
import br.com.healthtrack.data.dao.InstructorDAO;

public class InstructorTest {
    public static void main(String[] args) {
//        Instructor instrutorTeste1 = ObjectFactory.createInstructor1();
//        Instructor instrutorTeste2 = ObjectFactory.createInstructor2();
//        Instructor instrutorTeste3 = ObjectFactory.createInstructor3();
//        Instructor instrutorTeste4 = ObjectFactory.createInstructor4();
//        Instructor instrutorTeste5 = ObjectFactory.createInstructor5();
//
//
//        new InstructorDAO().create(instrutorTeste1);
//        new InstructorDAO().create(instrutorTeste2);
//        new InstructorDAO().create(instrutorTeste3);
//        new InstructorDAO().create(instrutorTeste4);
//        new InstructorDAO().create(instrutorTeste5);

        // Esses dados já estão criados no banco de dados, caso rode o código acima, certifique-se de dropar todas as tabelas relacionadas a Instrutor

        List<Instructor> listaInstructor = new InstructorDAO().selectAll();
        for (Instructor item : listaInstructor) {
            System.out.println("CREF do Instrutor " + item.getCref());
        }

    }
}
