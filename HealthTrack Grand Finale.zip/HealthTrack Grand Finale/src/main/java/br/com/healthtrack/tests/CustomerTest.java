package br.com.healthtrack.tests;

import java.util.ArrayList;
import java.util.List;

import br.com.healthtrack.business.model.user.Customer;
import br.com.healthtrack.business.model.user.Goal;
import br.com.healthtrack.data.dao.CustomerDAO;
import br.com.healthtrack.data.dao.GoalDao;

public class CustomerTest {
    public static void main(String[] args) {

        List<Customer> testUsers = new ArrayList<>();
        testUsers.add(ObjectFactory.createCustomer1());
        testUsers.add(ObjectFactory.createCustomer2());
        testUsers.add(ObjectFactory.createCustomer3());
        testUsers.add(ObjectFactory.createCustomer4());
        testUsers.add(ObjectFactory.createCustomer5());

        GoalDao goalDao = new GoalDao();

        List<Goal> availableGoals = goalDao.selectAll();
        CustomerDAO customerDAO = new CustomerDAO();
        for (Customer customer : testUsers) {
            for (Goal goal : availableGoals) {
                System.out.println(goal.toString());
                customer.addGoal(goal);
            }
            customerDAO.create(customer);
        }

        CustomerDAO dao = new CustomerDAO();
        List<Customer> lista = dao.selectAll();
        for (Customer item : lista) {
            System.out.println("ID: " + item.getId() + " Altura: " + item.getHeight());
        }
    }
}
