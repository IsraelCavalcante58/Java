package br.com.healthtrack.business.model.diet;

import java.io.Serializable;

public class Ingredient implements Serializable {
    private long id;
    private long mealOptionId;
    private String name;
    private int quantity;
    private MeasurementUnit unit;

    public Ingredient(String name, int quantity, MeasurementUnit unit) {
        this.name = name;
        this.quantity = quantity;
        this.unit = unit;
    }

    public Ingredient(long id, String name, int quantity, MeasurementUnit unit) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.unit = unit;
    }

    public void setMealOptionId(long mealOptionId) {
        this.mealOptionId = mealOptionId;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public MeasurementUnit getUnit() {
        return unit;
    }

    public void setUnit(MeasurementUnit unit) {
        this.unit = unit;
    }

    @Override
    public String toString() {
        return new StringBuilder()
                .append(quantity + " ")
                .append(unit.getDescription() + " de ")
                .append(name)
                .toString();
    }
}
