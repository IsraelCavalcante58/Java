package br.com.healthtrack.business.model.user;

import java.time.Instant;
import java.util.Date;

import br.com.healthtrack.business.model.diet.MeasurementUnit;

/**
 * Classe que faz o registro do peso do customer em determinada data para complementar a classe WeightHistory
 */
public class WeightRecord {
    private Date date;
    private Double weight;
    private long idUser;

    public void setDate(Date date) {
        this.date = date;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public long getIdUser() {
        return idUser;
    }

    public void setIdUser(long idUser) {
        this.idUser = idUser;
    }

    public Date getDate() {
        return date;
    }

    public Double getWeight() {
        return weight;
    }

    /**
     * Construtor que recebe o peso do customer numa data especifica
     *
     * @param weight peso do customer
     */
    public WeightRecord(Double weight) {
        this.weight = weight;
        this.date = Date.from(Instant.now());
    }

    public WeightRecord(Date date, Double weight) {
        this.date = date;
        this.weight = weight;
    }

    public WeightRecord(Date date, Double weight, long idUser) {
        this.date = date;
        this.weight = weight;
        this.idUser = idUser;
    }

    @Override
    public String toString() {
        return date.toString() + ":" + weight.toString() + MeasurementUnit.KILOS.getDescription();
    }
}
