package br.com.healthtrack.tests;

import java.util.List;

import br.com.healthtrack.business.model.user.Nutritionist;
import br.com.healthtrack.data.dao.NutritionistDAO;


public class NutritionistTest {
    public static void main(String[] args) {

//        Nutritionist nutricionistaTest1 = ObjectFactory.createNutritionist1();
//        Nutritionist nutricionistaTest2 = ObjectFactory.createNutritionist2();
//        Nutritionist nutricionistaTest3 = ObjectFactory.createNutritionist3();
//        Nutritionist nutricionistaTest4 = ObjectFactory.createNutritionist4();
//        Nutritionist nutricionistaTest5 = ObjectFactory.createNutritionist5();
//
//        new NutritionistDAO().create(nutricionistaTest1);
//        new NutritionistDAO().create(nutricionistaTest2);
//        new NutritionistDAO().create(nutricionistaTest3);
//        new NutritionistDAO().create(nutricionistaTest4);
//        new NutritionistDAO().create(nutricionistaTest5);

        // Esses dados já estão criados no banco de dados, caso rode o código acima, certifique-se de dropar todas as tabelas relacionadas a Nutritionist


        List<Nutritionist> listaNutritionist = new NutritionistDAO().selectAll();
        for (Nutritionist item : listaNutritionist) {
            System.out.println("ID do Nutricionista: " + item.getId() + " Documento do Nutricionista " + item.getCrm());
        }
    }

}
