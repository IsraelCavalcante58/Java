package br.com.healthtrack.tests;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import br.com.healthtrack.business.model.user.Customer;
import br.com.healthtrack.business.model.user.WeightRecord;
import br.com.healthtrack.data.dao.CustomerDAO;
import br.com.healthtrack.data.dao.WeightRecordDAO;

public class WeightRecordTest {
    public static void main(String[] args) {

        CustomerDAO customerDAO = new CustomerDAO();
        Customer customer = customerDAO.findById(183);
        Calendar date = new GregorianCalendar(2022, 5, 26);
//        WeightRecord record = new WeightRecord(date.getTime(), 95.0, customer.getId());
//
        WeightRecordDAO dao = new WeightRecordDAO();

//        dao.create(record);
        List<WeightRecord> customerWeightHistory = dao.findWeightHistoryByUserId(customer.getId());
        customer.setWeightHistory(customerWeightHistory);
        System.out.println(customer.getHistoricoPeso());

    }
}
