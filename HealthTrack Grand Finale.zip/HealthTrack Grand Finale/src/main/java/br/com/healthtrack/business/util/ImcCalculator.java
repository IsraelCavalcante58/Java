package br.com.healthtrack.business.util;
// Classe não implementada
public class ImcCalculator {
}
