package br.com.healthtrack.data.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.healthtrack.business.model.user.Customer;
import br.com.healthtrack.business.model.user.Gender;
import br.com.healthtrack.business.model.user.WeightRecord;
import br.com.healthtrack.data.model.GoalPerUser;

public class CustomerDAO implements DaoCRUD<Customer> {
    private PersonDAO personDAO = new PersonDAO();
    private GoalDao goalDao = new GoalDao();
    private GoalPerUserDAO goalPerUserDAO = new GoalPerUserDAO();
    private WeightRecordDAO weightRecordDAO = new WeightRecordDAO();

    @Override
    public int create(Customer customer) {
        PreparedStatement statement;
        try {

            connection.beginRequest();

            personDAO.create(customer);

            statement = connection.prepareStatement(
                    "INSERT INTO T_HT_CUSTOMER(T_HT_PERSON_ID_PERSON, VL_HEIGHT)" +
                            "VALUES (SQ_PERSON.CURRVAL, ?)");

            statement.setInt(1, customer.getHeight());
            databaseManager.executeWriteQuery(statement);

            PreparedStatement customerStatement = connection.prepareStatement(
                    "SELECT * FROM T_HT_CUSTOMER ORDER BY T_HT_PERSON_ID_PERSON DESC FETCH FIRST 1 ROWS ONLY");


            ResultSet customerResultSet = databaseManager.executeReadQuery(customerStatement);

            if (customerResultSet.next()) {
                long customerId = customerResultSet.getInt("T_HT_PERSON_ID_PERSON");
                updateWeightRecordsWithUserId(customerId, customer.getHistoricoPeso());
                GoalPerUser goalPerUser = new GoalPerUser(customerId, customer.getGoals());
                int affectedRows = goalPerUserDAO.create(goalPerUser);
                connection.endRequest();
                return affectedRows;
            }

        } catch (SQLException e) {
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (CUSTOMERDAO - CREATE)");
            e.printStackTrace();
        }
        return 0;
    }

    private void updateWeightRecordsWithUserId(Long customerId, List<WeightRecord> records) {
        for (WeightRecord record : records) {
            record.setIdUser(customerId);
            weightRecordDAO.create(record);
        }
    }

    public Customer getCustomerDataByEmail(String email) {
        ResultSet resultSet = null;
        Customer customer = null;
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT\n" +
                    "    c.id_person,\n" +
                    "    c.nm_name,\n" +
                    "    c.em_email,\n" +
                    "    c.ps_pass,\n" +
                    "    c.ft_photo,\n" +
                    "    c.dt_birthdate,\n" +
                    "    c.gen_gender,\n" +
                    "    b.id_weight_record,\n" +
                    "    b.t_ht_customer_id_person,\n" +
                    "    b.dt_date_record,\n" +
                    "    b.vl_weight,\n" +
                    "    a.t_ht_person_id_person,\n" +
                    "    a.vl_height\n" +
                    "FROM\n" +
                    "    t_ht_weight_record b,\n" +
                    "    t_ht_customer      a,\n" +
                    "    t_ht_person        c\n" +
                    "WHERE\n" +
                    "        a.t_ht_person_id_person = b.t_ht_customer_id_person\n" +
                    "    AND c.id_person = a.t_ht_person_id_person AND EM_EMAIL = ?");
            statement.setString(1, email);
            resultSet = databaseManager.executeReadQuery(statement);
            while (resultSet.next()) {
                customer = new Customer(resultSet.getLong("ID_PERSON"),
                        resultSet.getString("nm_name")
                        , resultSet.getString("PS_PASS")
                        , new WeightRecord(Double.valueOf(resultSet.getFloat("vl_weight")))
                        , resultSet.getInt("vl_height")
                        ,resultSet.getString("dt_birthdate")
                        , resultSet.getString("em_email")
                        , Gender.getEnumByValue(resultSet.getInt("gen_gender")));
                List<WeightRecord> record = weightRecordDAO.findWeightHistoryByUserId(customer.getId());
                customer.setWeightHistory(record);
            }
        } catch (SQLException e) {
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (CUSTOMERDAO - getCustomerDataByEmail)");
            e.printStackTrace();
        }
        return customer;
    }

    @Override
    public int update(Customer customer) {
        return 0;
    }


    @Override
    public int update(List<Customer> t) {
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int delete(Customer customer) {
        return 0;
    }

    @Override
    public Customer findById(int id) {
        ResultSet resultSet = null;
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM T_HT_CUSTOMER WHERE T_HT_PERSON_ID_PERSON = ?");
            statement.setLong(1, id);
            resultSet = databaseManager.executeReadQuery(statement);

            if (resultSet.next()) {
                return new Customer(resultSet.getInt("T_HT_PERSON_ID_PERSON"));
            }
        } catch (SQLException e) {
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (CUSTOMERDAO - FindByID)");
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Customer> selectAll() {
        Customer customer = null;
        List<Customer> listaCustomer = new ArrayList<>();
        ResultSet resultSet = null;

        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM T_HT_CUSTOMER");
            resultSet = databaseManager.executeReadQuery(statement);
            while (resultSet.next()) {
                int id = resultSet.getInt("T_HT_PERSON_ID_PERSON");
                int height = resultSet.getInt("VL_HEIGHT");
                customer = new Customer(id, height);
                listaCustomer.add(customer);

            }
        } catch (SQLException e) {
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (CUSTOMERDAO - SelectAll)");
        }
        return listaCustomer;
    }


}
