package br.com.healthtrack.data.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.healthtrack.business.model.user.WeightRecord;

public class WeightRecordDAO implements DaoCRUD<WeightRecord> {


    @Override
    public int create(WeightRecord weightRecord) {
        PreparedStatement statement;
        try {
            connection.beginRequest();

            statement = connection.prepareStatement(
                    "INSERT INTO T_HT_WEIGHT_RECORD(ID_WEIGHT_RECORD, T_HT_CUSTOMER_ID_PERSON, DT_DATE_RECORD, VL_WEIGHT)" +
                            "VALUES (SQ_WEIGHT_RECORD.NEXTVAL, ?, ?, ?)");

            statement.setLong(1, weightRecord.getIdUser());
            Date data = new Date(weightRecord.getDate().getTime());
            statement.setDate(2, data);
            statement.setDouble(3, weightRecord.getWeight());

            databaseManager.executeWriteQuery(statement);
        } catch (SQLException e) {
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (CUSTOMERDAO - CREATE)");
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int update(WeightRecord weightRecord) {
        return 0;
    }

    @Override
    public int update(List<WeightRecord> t) {
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int delete(WeightRecord weightRecord) {
        return 0;
    }

    @Override
    public WeightRecord findById(int id) {
        return null;
    }

    @Override
    public List<WeightRecord> selectAll() {
        return null;
    }

    public List<WeightRecord> findWeightHistoryByUserId(long userId) {
        List<WeightRecord> weightHistory = new ArrayList<>();
        ResultSet resultSet = null;
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM T_HT_WEIGHT_RECORD WHERE T_HT_CUSTOMER_ID_PERSON = ?");
            statement.setLong(1, userId);
            resultSet = databaseManager.executeReadQuery(statement);

            while (resultSet.next()) {
                weightHistory.add(
                        new WeightRecord(
                                resultSet.getDate("DT_DATE_RECORD"),
                                resultSet.getDouble("VL_WEIGHT"),
                                resultSet.getLong("T_HT_CUSTOMER_ID_PERSON")
                        )
                );
            }
        } catch (SQLException e) {
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (CUSTOMERDAO - FindByID)");
            e.printStackTrace();
        }
        return weightHistory;
    }
}
