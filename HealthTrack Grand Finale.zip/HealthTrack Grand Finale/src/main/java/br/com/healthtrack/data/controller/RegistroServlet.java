package br.com.healthtrack.data.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.healthtrack.business.model.user.Customer;
import br.com.healthtrack.business.model.user.Gender;
import br.com.healthtrack.business.model.user.WeightRecord;
import br.com.healthtrack.data.dao.CustomerDAO;

@WebServlet(name = "registro", value = "/registro")
public class RegistroServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String birthDate = request.getParameter("birthDate");
        int gender = Integer.parseInt(request.getParameter("gender"));
        int height = Integer.parseInt(request.getParameter("height"));
        Double weight = Double.parseDouble(request.getParameter("weight"));

        CustomerDAO customerDAO = new CustomerDAO();
        Customer customer = new Customer(0L, name, password, new WeightRecord(weight), height, birthDate, email, Gender.getEnumByValue(gender));
        customerDAO.create(customer);
    }
}

