package br.com.healthtrack.data.dao;

import java.util.List;

import br.com.healthtrack.business.model.user.Customer;

public class RegistroDAO implements DaoCRUD<Customer> {

    public Customer registerCustomer(Customer customer){



        return customer;
    }


    @Override
    public int create(Customer customer) {
        return 0;
    }

    @Override
    public int update(Customer customer) {
        return 0;
    }

    @Override
    public int update(List<Customer> t) {
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int delete(Customer customer) {
        return 0;
    }

    @Override
    public Customer findById(int id) {
        return null;
    }

    @Override
    public List<Customer> selectAll() {
        return null;
    }
}
