package br.com.healthtrack.business.model.user;

import static br.com.healthtrack.business.model.user.Customer.customers;

/**
 * Goal cria uma meta para o customer com os parametros idGoal, goalType e goalTimer
 */
public class Goal {

    private long idGoal;
    private String goalType;

    public long getId() {
        return idGoal;
    }

    public void setGoalId(long idGoal) {
        this.idGoal = idGoal;
    }

    public String getGoalType() {
        return goalType;
    }

    public void setGoalType(String goalType) {
        this.goalType = goalType;
    }

    /**
     * Metodo para adicionar uma goal a um usuario especifico
     *
     * @param goal     recebe uma goal a qual sera adicionado ao usuario
     * @param idPessoa recebe o identificador unico do usuario, para atribuir a ele a goal
     * @return
     */

    public Goal goalAdd(Goal goal, long idPessoa) {
        for (Customer usuario : customers) {
            if (usuario.getId() == idPessoa) {
                usuario.setMeta(goal);
            }
        }
        return goal;
    }

    /**
     * Construtor com os parametros necessarios para adicionar uma goal a um usuario
     *
     * @param idGoal   recebe um identificador unico
     * @param goalType recebe o nome da goal ex: musculacao
     */

    public Goal(long idGoal, String goalType) {
        this.idGoal = idGoal;
        this.goalType = goalType;
    }


    // Estou sobrescrevendo o método ToString para printar os valores de forma correta


    @Override
    public String toString() {
        return " ID: " + idGoal +
                " Tipo Meta: " + goalType;
    }
}
