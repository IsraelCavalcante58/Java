package br.com.healthtrack.data.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.healthtrack.business.model.user.Nutritionist;

public class NutritionistDAO implements  DaoCRUD<Nutritionist>{


    private PersonDAO personDAO = new PersonDAO();

    @Override
    public int create(Nutritionist nutritionist) {
        PreparedStatement statement;
        try {
            personDAO.create(nutritionist);

            statement = connection.prepareStatement(
                    "INSERT INTO T_HT_NUTRITIONIST(T_HT_PERSON_ID_PERSON, DOC_CFN)" +
                            " VALUES (SQ_PERSON.CURRVAL, ?)");

            statement.setString(1, nutritionist.getCrm());
            return databaseManager.executeWriteQuery(statement);

        } catch (SQLException e) {
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (CUSTOMERDAO)");
            e.printStackTrace();
        }
        return 0;
    }



    @Override
    public int update(Nutritionist nutritionist) {
        return 0;
    }

    @Override
    public int update(List<Nutritionist> t) {
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int delete(Nutritionist nutritionist) {
        return 0;
    }

    @Override
    public Nutritionist findById(int id) {
        return null;
    }


    @Override
    public List<Nutritionist> selectAll() {
        Nutritionist nutritionist = null;
        List<Nutritionist> listaCustomer = new ArrayList<>();
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try{
            statement = connection.prepareStatement("SELECT * FROM T_HT_NUTRITIONIST");
            resultSet = databaseManager.executeReadQuery(statement);
            while (resultSet.next()){
                int id = resultSet.getInt("T_HT_PERSON_ID_PERSON");
                String docCfn = resultSet.getString("DOC_CFN");
                nutritionist = new Nutritionist(id, docCfn);
                listaCustomer.add(nutritionist);
            }
        } catch (SQLException e){
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (CUSTOMERDAO - SelectAll)");
        }
        return listaCustomer;
    }
}
