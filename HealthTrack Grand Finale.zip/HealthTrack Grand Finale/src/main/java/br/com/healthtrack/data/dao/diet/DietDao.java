package br.com.healthtrack.data.dao.diet;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import br.com.healthtrack.business.model.diet.Diet;
import br.com.healthtrack.business.model.diet.Meal;
import br.com.healthtrack.data.dao.DaoCRUD;

public class DietDao implements DaoCRUD<Diet> {

    @Override
    public int create(Diet diet) {
        try {
            insertDietIntoDatabase(diet); // Inserindo objeto java no banco de dados
            Diet storedDiet = retrieveDietFromDatabase(); // resgatando um objeto Java do banco de dados.
            storedDiet.setMeals(diet.getMeals()); // atribuindo as refeições da dieta criada pelo usuário a partir de uma interface gráfica para o objeto criado a partir do banco de dados.
            populateMealsTable(storedDiet); //inserir no banco de dados as refeições com o id da dieta que resgatamos do banco de dados
        } catch (SQLException e) {
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (IngredientDAO - CREATE)");
            e.printStackTrace();
        }
        return 0;
    }

    private void populateMealsTable(Diet storedDiet) {
        MealDao mealDao = new MealDao();
        for (Meal meal : storedDiet.getMeals()) {
            meal.setIdDiet(storedDiet.getId());// Para cada refeição de uma dieta atribuímos o id da dieta no banco de dados
            mealDao.create(meal); //cria a refeição com o id da dieta <3
        }
    }

    private Diet retrieveDietFromDatabase() throws SQLException {
        ResultSet dietResultSet;
        PreparedStatement dietStatement = connection.prepareStatement(
                "SELECT * FROM T_HT_DIET ORDER BY ID_DIET DESC FETCH FIRST 1 ROWS ONLY");

        dietResultSet = databaseManager.executeReadQuery(dietStatement);
        if (dietResultSet.next()) {
            return new Diet(
                    dietResultSet.getLong("ID_DIET"),
                    dietResultSet.getLong("T_HT_APPOINTMENT_ID_APPOINTMENT"),
                    dietResultSet.getLong("T_HT_NUTRITIONIST_DOC_CFN"),
                    dietResultSet.getLong("T_HT_CUSTOMER_T_HT_PERSON_ID_PERSON"),
                    null,
                    dietResultSet.getString("DS_ADD_INSTRUCTIONS")
            );
        }
        return null;
    }

    private int insertDietIntoDatabase(Diet diet) throws SQLException {
        PreparedStatement statement;
        statement = connection.prepareStatement(
                "INSERT INTO T_HT_DIET(ID_DIET, DS_ADD_INSTRUCTIONS,T_HT_CUSTOMER_T_HT_PERSON_ID_PERSON)" +
                        " VALUES (SQ_DIET.NEXTVAL, ?, ?)");

        statement.setString(1, diet.getAdditionalInstructions());
        statement.setLong(2, diet.getIdUser());

        return databaseManager.executeWriteQuery(statement);
    }

    @Override
    public int update(Diet diet) {
        return 0;
    }

    @Override
    public int update(List<Diet> t) {
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int delete(Diet diet) {
        return 0;
    }

    @Override
    public Diet findById(int id) {
        return null;
    }

    @Override
    public List<Diet> selectAll() {
        return null;
    }
}
