package br.com.healthtrack.data.dao.diet;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import br.com.healthtrack.business.model.diet.Ingredient;
import br.com.healthtrack.data.dao.DaoCRUD;

public class IngredientDAO implements DaoCRUD<Ingredient> {

    @Override
    public int create(Ingredient ingredient) {
        try {
            insertIngredientIntoDatabase(ingredient);


        } catch (SQLException e) {
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (IngredientDAO - CREATE)");
            e.printStackTrace();
        }
        return 0;
    }

    private int insertIngredientIntoDatabase(Ingredient ingredient) throws SQLException {
        PreparedStatement statement;
        statement = connection.prepareStatement(
                "INSERT INTO T_HT_INGREDIENT(ID_INGREDIENT, NM_NAME)" +
                        " VALUES (SQ_INGREDIENT.NEXTVAL, ?)");

        statement.setString(1, ingredient.getName());
        return databaseManager.executeWriteQuery(statement);
    }

    @Override
    public int update(Ingredient ingredientEntity) {
        return 0;
    }

    @Override
    public int update(List<Ingredient> t) {
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int delete(Ingredient ingredientEntity) {
        return 0;
    }

    @Override
    public Ingredient findById(int id) {
        ResultSet resultSet;
        try {
            PreparedStatement statement = connection.prepareStatement(
                    "SELECT * FROM T_HT_INGREDIENT" +
                            " WHERE ID_INGREDIENT = ?");
            statement.setInt(1, id);
            resultSet = databaseManager.executeReadQuery(statement);

            if (resultSet.next()) {
//                return new Ingredient(
//                        resultSet.getLong("ID_INGREDIENT"),
//                        resultSet.getString("NM_NAME"));
            }
        } catch (SQLException e) {
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (IngredientDAO - FindByName)");
            e.printStackTrace();
        }
        return null;
    }

    public IngredientEntity findByName(String name) {
        ResultSet resultSet;
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM T_HT_INGREDIENT WHERE NM_NAME LIKE ?");
            statement.setString(1, name);
            resultSet = databaseManager.executeReadQuery(statement);

            if (resultSet.next()) {
                return new IngredientEntity(
                        resultSet.getLong("ID_INGREDIENT"),
                        resultSet.getString("NM_NAME"));
            }
        } catch (SQLException e) {
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (IngredientDAO - FindByName)");
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Ingredient> selectAll() {
        return null;
    }
}