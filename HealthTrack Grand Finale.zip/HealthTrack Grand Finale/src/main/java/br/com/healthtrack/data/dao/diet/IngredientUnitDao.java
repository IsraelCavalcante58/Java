package br.com.healthtrack.data.dao.diet;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import br.com.healthtrack.business.model.diet.Ingredient;
import br.com.healthtrack.data.dao.DaoCRUD;

public class IngredientUnitDao implements DaoCRUD<Ingredient> {

    @Override
    public int create(Ingredient ingredient) {
        PreparedStatement statement;

        try {
            statement = connection.prepareStatement(
                    "INSERT INTO T_HT_UNIT_INGREDIENT(ID_UNIT_INGREDIENT, T_HT_INGREDIENT_ID_INGREDIENT, T_HT_UNIT_ID_UNIT, VL_QTD)" +
                            " VALUES (SQ_UNIT_INGREDIENT.NEXTVAL, ?, ?, ?)");
            statement.setLong(1, ingredient.getId());
            statement.setLong(2, ingredient.getUnit().getId());
            statement.setInt(3, ingredient.getQuantity());

            return databaseManager.executeWriteQuery(statement);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int update(Ingredient ingredient) {
        return 0;
    }

    @Override
    public int update(List<Ingredient> t) {
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int delete(Ingredient ingredient) {
        return 0;
    }

    @Override
    public Ingredient findById(int id) {
        return null;
    }

    @Override
    public List<Ingredient> selectAll() {
        return null;
    }
}

