package br.com.healthtrack.tests;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import br.com.healthtrack.business.model.user.Person;
import br.com.healthtrack.data.dao.PersonDAO;

public class PersonTest {

    public static int dateToCalendar(Date date) {
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        int year = calendar.get(Calendar.YEAR);

        return year;
    }

    public static void main(String[] args) {

        List<Person> listPerson = new PersonDAO().selectAll();
        for (Person item : listPerson) {
            System.out.println("ID da pessoa: " + item.getId() + " Nome da pessoa " + item.getName() + " Email da pessoa: "
                    + item.getEmail() + " Senha da pessoa: " + item.getPassword() + " Gênero da pessoa: " + item.getGender()
                    + " Data de nascimento da pessoa " + dateToCalendar(item.getBirthDate()));
        }
    }

}
