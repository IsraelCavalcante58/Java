package br.com.healthtrack.data.dao.diet;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import br.com.healthtrack.business.model.diet.Ingredient;
import br.com.healthtrack.business.model.diet.MealOption;
import br.com.healthtrack.data.dao.DaoCRUD;

public class MealOptionDAO implements DaoCRUD<MealOption> {


    @Override
    public int create(MealOption mealOption) {
        try {
            insertMealOptionIntoDatabase(mealOption);
            MealOption retrievedMealOption = retrieveLastMealOption();
            retrievedMealOption.setIngredients(mealOption.getIngredients());
            createIngredients(mealOption);
        } catch (SQLException e) {
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (IngredientDAO - CREATE)");
            e.printStackTrace();
        }
        return 0;
    }

    private void createIngredients(MealOption mealOption) {
        IngredientUnitDao ingredientUnitDao = new IngredientUnitDao();

        for (Ingredient ingredient : mealOption.getIngredients()) {
            ingredient.setMealOptionId(mealOption.getId());
            ingredientUnitDao.create(ingredient);
        }
    }

    private MealOption retrieveLastMealOption() throws SQLException {
        PreparedStatement customerStatement = connection.prepareStatement(
                "SELECT * FROM T_HT_MEAL_OPTION ORDER BY ID_MEAL_OPTION DESC FETCH FIRST 1 ROWS ONLY");

        ResultSet retrievedMealOption = databaseManager.executeReadQuery(customerStatement);
        if (retrievedMealOption.next()) {
            return new MealOption(retrievedMealOption.getLong("ID_MEAL_OPTION"),
                    retrievedMealOption.getString("DS_INSTRUCTIONS"));
        }
        return null;
    }

    private void insertMealOptionIntoDatabase(MealOption mealOption) throws SQLException {
        PreparedStatement statement;
        connection.beginRequest();
        statement = connection.prepareStatement(
                "INSERT INTO T_HT_MEAL_OPTION(ID_MEAL_OPTION, DS_INSTRUCTIONS)" +
                        " VALUES (SQ_MEAL_OPTION.NEXTVAL, ?)");

        statement.setString(1, mealOption.getInstructions());
        databaseManager.executeWriteQuery(statement);
    }

    @Override
    public int update(MealOption mealOption) {
        return 0;
    }

    @Override
    public int update(List<MealOption> t) {
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int delete(MealOption mealOption) {
        return 0;
    }

    @Override
    public MealOption findById(int id) {
        return null;
    }

    @Override
    public List<MealOption> selectAll() {
        return null;
    }
}
