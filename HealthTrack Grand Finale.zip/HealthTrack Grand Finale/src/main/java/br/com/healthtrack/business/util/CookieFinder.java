package br.com.healthtrack.business.util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

public class CookieFinder {

    public static String getCookie(HttpServletRequest request,String cookieKey){

        Cookie ck[]=request.getCookies();
        for (Cookie element : ck) {
            if (element.getName().equalsIgnoreCase(cookieKey)){
                return ck[0].getValue();
            }
        }
        return null;
    }
}
