package br.com.healthtrack.tests;

import java.util.ArrayList;
import java.util.List;

import br.com.healthtrack.business.model.diet.Diet;
import br.com.healthtrack.business.model.diet.Ingredient;
import br.com.healthtrack.business.model.diet.Meal;
import br.com.healthtrack.business.model.diet.MealOption;
import br.com.healthtrack.business.model.diet.MeasurementUnit;
import br.com.healthtrack.data.dao.diet.DietDao;
import br.com.healthtrack.data.dao.diet.IngredientDAO;
import br.com.healthtrack.data.dao.diet.IngredientEntity;
import br.com.healthtrack.data.dao.diet.MealOptionDAO;
import br.com.healthtrack.data.dao.diet.MeasurementUnitDAO;

public class DietTest {
    public static void main(String[] args) {

//        initMeasurementUnitTable();
//        initIngredientsTable();
        IngredientDAO ingredientDAO = new IngredientDAO();
        MealOptionDAO mealOptionDAO = new MealOptionDAO();
        //Montar uma receita Bolo de Caneca
        //1 banana
        //2 colheres de Farelo de Aveia
        //1 colher de cacau em pó;
        //1 ovo
        // Misturar todos os ingredientes numa caneca e levar ao microondas por 3 minutos

        IngredientEntity banana = ingredientDAO.findByName("Banana");
        IngredientEntity oat = ingredientDAO.findByName("Farelo de aveia");
        IngredientEntity cocoa = ingredientDAO.findByName("Cacau em p�");
        IngredientEntity egg = ingredientDAO.findByName("Ovo");
        List<Ingredient> ingredients = new ArrayList();

        ingredients.add(new Ingredient(banana.getId(), banana.getName(), 1, MeasurementUnit.UNIT));
        ingredients.add(new Ingredient(oat.getId(), oat.getName(), 2, MeasurementUnit.SPOON));
        ingredients.add(new Ingredient(cocoa.getId(), cocoa.getName(), 1, MeasurementUnit.SPOON));
        ingredients.add(new Ingredient(egg.getId(), egg.getName(), 1, MeasurementUnit.UNIT));


        MealOption bananaMugCake = new MealOption(ingredients, "Misturar todos os ingredientes numa caneca e levar ao microondas por 3 minutos");

        List<MealOption> mealOptions = new ArrayList();
        mealOptions.add(bananaMugCake);

        Meal breakfast = new Meal("Café da manhã", mealOptions);

        List<Meal> meals = new ArrayList<>();
        meals.add(breakfast);

        Diet diet = new Diet(0,0,193,183, meals,"Beber 2 copos de água ao acordar");

        DietDao dietDao = new DietDao();
        dietDao.create(diet);
    }

    private static void initMeasurementUnitTable() {
        MeasurementUnitDAO measurementUnitDAO = new MeasurementUnitDAO();
        for (MeasurementUnit unit : MeasurementUnit.values()) {
            measurementUnitDAO.create(unit);
        }
    }

//    private static void initIngredientsTable() {
//        IngredientDAO ingredientDAO = new IngredientDAO();
//
//        for (IngredientEntity ingredient : createIngredients()) {
//            ingredientDAO.create(ingredient);
//        }
//    }

    private static List<IngredientEntity> createIngredients() {

        List<IngredientEntity> ingredients = new ArrayList<>();
        ingredients.add(new IngredientEntity("Banana"));
        ingredients.add(new IngredientEntity("Aveia"));
        ingredients.add(new IngredientEntity("Arroz Integral"));
        ingredients.add(new IngredientEntity("Feijão"));
        ingredients.add(new IngredientEntity("Peito de Frango"));
        ingredients.add(new IngredientEntity("Posta de Salmão"));
        ingredients.add(new IngredientEntity("Ovo"));
        ingredients.add(new IngredientEntity("Salada"));
        ingredients.add(new IngredientEntity("Iogurte"));
        ingredients.add(new IngredientEntity("Adoçante Stévia"));
        ingredients.add(new IngredientEntity("Sal"));
        ingredients.add(new IngredientEntity("Chia"));
        ingredients.add(new IngredientEntity("Xilitol"));
        ingredients.add(new IngredientEntity("Carne Vermelha"));
        ingredients.add(new IngredientEntity("Peixe"));
        ingredients.add(new IngredientEntity("Macarrão Integral"));
        ingredients.add(new IngredientEntity("Cacau em pó"));
        ingredients.add(new IngredientEntity("Farelo de aveia"));


        return ingredients;
    }
}
