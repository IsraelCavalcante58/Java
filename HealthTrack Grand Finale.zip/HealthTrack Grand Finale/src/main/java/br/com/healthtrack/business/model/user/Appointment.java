package br.com.healthtrack.business.model.user;


import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Appointment implements Serializable {

    private long idAppointment;
    private Date dtAppointment;
    private boolean firstAppointment;
    private long idUser;
    private long idNutritionist;


    public long getIdAppointment() {
        return idAppointment;
    }

    public void setIdAppointment(long idAppointment) {
        this.idAppointment = idAppointment;
    }

    public Date getDtAppointment() {
        return dtAppointment;
    }

    public void setDtAppointment(Date dtAppointment) {
        this.dtAppointment = dtAppointment;
    }

    public boolean getIsFirstAppointment() {
        return firstAppointment;
    }

    public void setFirstAppointment(boolean firstAppointment) {
        this.firstAppointment = firstAppointment;
    }

    public long getIdUser() {
        return idUser;
    }

    public long getIdNutritionist() {
        return idNutritionist;
    }

    public Appointment() {}

    public Appointment(long idAppointment, String dtAppointment, boolean firstAppointment, long idUser, long idNutritionist) {
        this.idAppointment = idAppointment;
        try {
            if(dtAppointment.contains("/")){
                this.dtAppointment = new SimpleDateFormat("dd/MM/yyyy").parse(dtAppointment);

            }else{
                this.dtAppointment = new SimpleDateFormat("yyyy-dd-MM").parse(dtAppointment.split(" ")[0]);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        this.firstAppointment = firstAppointment;
        this.idUser = idUser;
        this.idNutritionist = idNutritionist;
    }
}
