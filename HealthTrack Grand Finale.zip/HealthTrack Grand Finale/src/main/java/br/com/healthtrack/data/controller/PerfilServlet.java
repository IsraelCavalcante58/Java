package br.com.healthtrack.data.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.healthtrack.business.model.user.Customer;
import br.com.healthtrack.business.util.CookieFinder;
import br.com.healthtrack.data.dao.CustomerDAO;

@WebServlet(name = "perfil", value = "/perfil")
public class PerfilServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cookie = CookieFinder.getCookie(request, "user");
        CustomerDAO customerDAO = new CustomerDAO();
        Customer customer =  customerDAO.getCustomerDataByEmail(cookie);
        request.setAttribute("customer", customer);
        request.getRequestDispatcher("perfil.jsp").forward(request, response);



    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
