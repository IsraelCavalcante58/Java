package br.com.healthtrack.data.model;

import java.util.List;

import br.com.healthtrack.business.model.user.Goal;

public class GoalPerUser {
    private long IdGoalPerUser;
    private long userId;
    private List<Goal> goals;

    public long getIdGoalPerUser() {
        return IdGoalPerUser;
    }



    public void setUserId(long userId) {
        this.userId = userId;
    }

    public void setGoals(List<Goal> goals) {
        this.goals = goals;
    }

    public long getIdGoal() {
        return idGoal;
    }

    public void setIdGoal(long idGoal) {
        this.idGoal = idGoal;
    }

    private long idGoal; // TODO apenas para gerar o construtor para ser utilizado no SelectAll irrelevante para o projeto final

    public GoalPerUser(long userId, List<Goal> goals) {
        this.userId = userId;
        this.goals = goals;
    }

    public GoalPerUser(long idGoalUser, long t_ht_customer_id_person, long t_ht_goal_id_goal) {
        this.IdGoalPerUser = idGoalUser;
        this.userId = t_ht_customer_id_person;
        this.idGoal = t_ht_goal_id_goal;
    }

    public List<Goal> getGoals() {
        return goals;
    }

    public long getUserId() {
        return userId;
    }
}
