package br.com.healthtrack.business.model.user;

import java.io.Serializable;

/**
 * Opcoes disponiveis para genero
 */
public enum Gender implements Serializable {
    MALE("Masculino", 1), FEMALE("Feminino", 2), OTHER("Outro", 3), NON_SPECIFIED("Não especificado", 4);

    private String identifier;
    private int code;

    Gender(String identifier, int code) {
        this.identifier = identifier;
        this.code = code;
    }

    public String getIdentifier() {
        return identifier;
    }

    public int getCode() {
        return code;
    }

    public static Gender getEnumByValue(int code) {
        for (Gender gender : Gender.values()) {
            if (gender.code == code) {

                return gender;
            }
        }

        throw new NullPointerException();
    }
}
