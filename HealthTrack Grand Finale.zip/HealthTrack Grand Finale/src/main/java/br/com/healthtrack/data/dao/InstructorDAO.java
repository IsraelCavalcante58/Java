package br.com.healthtrack.data.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.healthtrack.business.model.user.Instructor;

public class InstructorDAO implements DaoCRUD<Instructor> {

    private PersonDAO personDAO = new PersonDAO();

    @Override
    public int create(Instructor instructor) {
        PreparedStatement statement;
        try {
            personDAO.create(instructor);

            statement = connection.prepareStatement(
                    "INSERT INTO T_HT_INSTRUCTOR(T_HT_PERSON_ID_PERSON, DOC_CREF)" +
                            " VALUES (SQ_PERSON.CURRVAL, ?)");

            statement.setString(1, instructor.getCref());
            return databaseManager.executeWriteQuery(statement);

        } catch (SQLException e) {
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (INSTRUCTOR)");
            e.printStackTrace();
        }
        return 0;
    }




    @Override
    public int update(Instructor instructor) {
        return 0;
    }

    @Override
    public int update(List<Instructor> t) {
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int delete(Instructor instructor) {
        return 0;
    }

    @Override
    public Instructor findById(int id) {
        return null;
    }


    @Override
    public List<Instructor> selectAll() {
        Instructor instructor = null;
        List<Instructor> listaInstructor = new ArrayList<>();
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try{
            statement = connection.prepareStatement("SELECT * FROM T_HT_INSTRUCTOR");
            resultSet = databaseManager.executeReadQuery(statement);
            while (resultSet.next()){
                int id = resultSet.getInt("T_HT_PERSON_ID_PERSON");
                String cref= resultSet.getString("DOC_CREF");
                instructor= new Instructor(id, cref);
                listaInstructor.add(instructor);

            }
        } catch (SQLException e){
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (CUSTOMERDAO - SelectAll)");
        }
        return listaInstructor;
    }
}
