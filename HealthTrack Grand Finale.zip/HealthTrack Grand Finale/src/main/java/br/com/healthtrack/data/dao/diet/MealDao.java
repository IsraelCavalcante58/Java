package br.com.healthtrack.data.dao.diet;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import br.com.healthtrack.business.model.diet.Meal;
import br.com.healthtrack.business.model.diet.MealOption;
import br.com.healthtrack.data.dao.DaoCRUD;

public class MealDao implements DaoCRUD<Meal> {

    @Override
    public int create(Meal meal) {
        try {
            insertMealIntoDatabase(meal);
            Meal storedMeal = retrieveStorageMeal();
            storedMeal.setMealOptions(meal.getMealOptions());
            createMealOptions(storedMeal);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    private Meal retrieveStorageMeal() throws SQLException {
        PreparedStatement customerStatement = connection.prepareStatement(
                "SELECT * FROM T_HT_MEAL ORDER BY ID_MEAL DESC FETCH FIRST 1 ROWS ONLY");

        ResultSet retrievedMeal = databaseManager.executeReadQuery(customerStatement);
        if (retrievedMeal.next()) {
            return new Meal(retrievedMeal.getLong("ID_MEAL"),
                    retrievedMeal.getString("NM_NAME_MEAL"),
                    null,
                    retrievedMeal.getLong("T_HT_DIET_ID_DIET"));
        }
        return null;
    }

    private void createMealOptions(Meal meal) {
        MealOptionDAO mealOptionDAO = new MealOptionDAO();
        for (MealOption option : meal.getMealOptions()) {
            option.setMealId(meal.getId());
            mealOptionDAO.create(option);
        }
    }

    private void insertMealIntoDatabase(Meal meal) throws SQLException {
        PreparedStatement statement;
        statement = connection.prepareStatement(
                "INSERT INTO T_HT_MEAL(ID_MEAL, NM_NAME_MEAL, T_HT_DIET_ID_DIET)" +
                        " VALUES (SQ_MEAL.NEXTVAL, ?, ?)");

        statement.setString(1, meal.getName());
        statement.setLong(2, meal.getIdDiet());

        databaseManager.executeWriteQuery(statement);
    }

    @Override
    public int update(Meal meal) {
        return 0;
    }

    @Override
    public int update(List<Meal> t) {
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int delete(Meal meal) {
        return 0;
    }

    @Override
    public Meal findById(int id) {
        return null;
    }

    @Override
    public List<Meal> selectAll() {
        return null;
    }
}
