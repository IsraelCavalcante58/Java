package br.com.healthtrack.business.model.diet;

import java.io.Serializable;

public enum MeasurementUnit implements Serializable {
    GRAMS(1, "grama(s)", "g"),
    KILOS(2, "quilo(s)", "k"),
    CALORIES(3, "caloria(s)", "cal"),
    KILO_CALORIES(4, "quilo caloria(s)", "kcal"),
    LITERS(5, "litro(s)", "l"),
    MILLI_LITERS(6, "mililitro(s)", "ml"),
    UNIT(7, "unidade(s)", "un"),
    SPOON(8, "Colher de sopa", "col");

    private final int id;
    private final String description;
    private final String shortForm;

    MeasurementUnit(int id, String description, String shortForm) {
        this.id = id;
        this.description = description;
        this.shortForm = shortForm;
    }

    public String getDescription() {
        return description;
    }

    public String getShortForm() {
        return shortForm;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "MeasurementUnit{" +
                "description='" + description + '\'' +
                ", shortForm='" + shortForm + '\'' +
                '}';
    }
}
