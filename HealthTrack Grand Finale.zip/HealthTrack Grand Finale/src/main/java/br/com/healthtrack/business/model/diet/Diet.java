package br.com.healthtrack.business.model.diet;

import java.io.Serializable;
import java.util.List;

public class Diet implements Serializable {
    private long id;
    private long idAppointment;
    private long idNutritionist;
    private long idUser;
    private List<Meal> meals;
    private String additionalInstructions;

    public Diet(long idUser, List<Meal> meals, String additionalInstructions) {
        this.idUser = idUser;
        this.meals = meals;
        this.additionalInstructions = additionalInstructions;
    }

    public Diet(long idUser, List<Meal> meals) {
        this.idUser = idUser;
        this.meals = meals;
    }

    public Diet(long id, long idAppointment, long idNutritionist, long idUser, List<Meal> meals, String additionalInstructions) {
        this.id = id;
        this.idAppointment = idAppointment;
        this.idNutritionist = idNutritionist;
        this.idUser = idUser;
        this.meals = meals;
        this.additionalInstructions = additionalInstructions;
    }

    public long getIdAppointment() {
        return idAppointment;
    }

    public long getIdNutritionist() {
        return idNutritionist;
    }

    public Long getIdUser() {
        return idUser;
    }

    public void setIdUser(Long idUser) {
        this.idUser = idUser;
    }

    public List<Meal> getMeals() {
        return meals;
    }

    public void setMeals(List<Meal> meals) {
        this.meals = meals;
    }

    public String getAdditionalInstructions() {
        return additionalInstructions;
    }

    public void setAdditionalInstructions(String additionalInstructions) {
        this.additionalInstructions = additionalInstructions;
    }

    @Override
    public String toString() {
        return "Dieta do Usuário" +
                "idUser=" + idUser +
                ", meals=" + meals +
                ", additionalInstructions='" + additionalInstructions + '\'' +
                '}';
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
