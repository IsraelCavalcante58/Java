package br.com.healthtrack.data.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.healthtrack.business.model.user.Appointment;

public class AppointmentDAO implements DaoCRUD<Appointment> {

    @Override
    public int create(Appointment appointment) {
        PreparedStatement statement;
        try {
            insertAppointmentIntoDatabase(appointment); //Insert appointment java on DB
            //TODO: Implementar criaçÃo com dieta
//            Appointment storedAppointment = retrieveAppointmentFromDatabase();


        } catch (SQLException e) {
            System.out.println("Não achou a tabela ou não conectou ao banco de dados (Appointment DAO)");
            e.printStackTrace();
        }
        return 0;
    }
//    private void populateAppointmentTable(Appointment appointment) {
//        MealDao mealDao = new MealDao();
//        for (Meal meal : storedDiet.getMeals()) {
//            meal.setIdDiet(storedDiet.getId());// Para cada refeição de uma dieta atribuímos o id da dieta no banco de dados
//            mealDao.create(meal); //cria a refeição com o id da dieta <3
//        }
//    }

    private Appointment retrieveAppointmentFromDatabase() throws SQLException {
        ResultSet appointmentResultSet;
        PreparedStatement appointmentStatement = connection.prepareStatement(
                "SELECT * FROM T_HT_APPOINTMENT ORDER BY ID_APPOINTMENT DESC FETCH FIRST 1 ROWS ONLY");

        appointmentResultSet = databaseManager.executeReadQuery(appointmentStatement);

        return new Appointment(
                appointmentResultSet.getLong("ID_APPOINTMENT"),
                appointmentResultSet.getString("DT_APPOINTMENT"),
                appointmentResultSet.getBoolean("DS_FIRST_APPOINTMENT"),
                appointmentResultSet.getLong("T_HT_CUSTOMER_T_HT_PERSON_ID_PERSON"),
                appointmentResultSet.getLong("T_HT_NUTRITIONIST_DOC_CFN")
        );
    }


    private int insertAppointmentIntoDatabase(Appointment appointment) throws SQLException {
        PreparedStatement statement;
        statement = connection.prepareStatement(
                "INSERT INTO T_HT_APPOINTMENT (ID_APPOINTMENT, DT_APPOINTMENT, DS_FIRST_APPOINTMENT, T_HT_NUTRITIONIST_DOC_CFN)" +
                        "VALUES (SQ_APPOINTMENT.NEXTVAL, ?, ?, ?)");

        Date date = new Date(appointment.getDtAppointment().getTime());
        statement.setDate(1, date);
        statement.setBoolean(2, appointment.getIsFirstAppointment());
        statement.setString(3, String.valueOf(appointment.getIdNutritionist()));
//        statement.setLong(4, appointment.getIdUser());

        return databaseManager.executeWriteQuery(statement);
    }

    @Override
    public int update(Appointment appointment) {
        return 0;
    }

    @Override
    public int update(List<Appointment> t) {
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int delete(Appointment appointment) {
        return 0;
    }

    @Override
    public Appointment findById(int id) {
        return null;
    }

    @Override
    public List<Appointment> selectAll() {

        ResultSet resultSet;
        List<Appointment> appointments = new ArrayList<>();
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM T_HT_APPOINTMENT");
            resultSet = databaseManager.executeReadQuery(statement);

            while (resultSet.next()) {
                appointments.add(new Appointment(
                        resultSet.getLong("ID_APPOINTMENT"),
                        resultSet.getString("DT_APPOINTMENT"),
                        resultSet.getBoolean("DS_FIRST_APPOINTMENT"),
                        resultSet.getLong("T_HT_CUSTOMER_T_HT_PERSON_ID_PERSON"),
                        resultSet.getLong("T_HT_NUTRITIONIST_DOC_CFN"))
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return appointments;
    }
}

