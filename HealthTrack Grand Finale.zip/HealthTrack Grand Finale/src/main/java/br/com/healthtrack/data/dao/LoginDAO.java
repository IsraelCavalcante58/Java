package br.com.healthtrack.data.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import br.com.healthtrack.business.model.user.Person;

public class LoginDAO implements DaoCRUD<Person>{




    public static boolean validate(Person bean){
        ResultSet resultSet;

        PreparedStatement statement;

        boolean status=false;
        try{
            statement = connection.prepareStatement("select * from T_HT_PERSON where EM_EMAIL = ? and PS_PASS = ?");

            statement.setString(1,bean.getEmail().trim());
            statement.setString(2, bean.getPassword());

             resultSet = databaseManager.executeReadQuery(statement);
            status = resultSet.next();



        }catch(Exception e){}
        return status;
    }


    @Override
    public int create(Person person) {
        return 0;
    }

    @Override
    public int update(Person person) {
        return 0;
    }

    @Override
    public int update(List<Person> t) {
        return 0;
    }

    @Override
    public int delete(int id) {
        return 0;
    }

    @Override
    public int delete(Person person) {
        return 0;
    }

    @Override
    public Person findById(int id) {
        return null;
    }

    @Override
    public List<Person> selectAll() {
        return null;
    }
}
