package br.com.healthtrack.business.model.diet;

import java.io.Serializable;
import java.util.List;

public class Meal implements Serializable {
    private long id;
    private String name;
    private List<MealOption> mealOptions;
    private long idDiet;

    public Meal(long id, String name, List<MealOption> mealOptions, long idDiet) {
        this.id = id;
        this.name = name;
        this.mealOptions = mealOptions;
        this.idDiet = idDiet;
    }

    public Meal(String name, List<MealOption> mealOptions) {
        this.name = name;
        this.mealOptions = mealOptions;
    }

    public long getId() {
        return id;
    }

    public long getIdDiet() {
        return idDiet;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<MealOption> getMealOptions() {
        return mealOptions;
    }

    public void setMealOptions(List<MealOption> mealOptions) {
        this.mealOptions = mealOptions;
    }

    @Override
    public String toString() {
        return "Nome da Refeição " + name;
    }


    public void setIdDiet(long id) {
        this.idDiet = id;
    }
}

